package com.ventra.business

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Gold = Color(0xFFC49A36)
private val Ink = Color(0xFF20232A)
private val Paper = Color(0xFFF7F5EF)

class StoreDb(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "ventra_local.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,qty REAL NOT NULL,price REAL NOT NULL,cost REAL NOT NULL)")
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,title TEXT NOT NULL,amount REAL NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addProduct(name: String, qty: Double, price: Double, cost: Double) {
        writableDatabase.insert("products", null, ContentValues().apply { put("name",name); put("qty",qty); put("price",price); put("cost",cost) })
    }
    fun products(): List<Product> {
        val out = mutableListOf<Product>(); readableDatabase.rawQuery("SELECT id,name,qty,price,cost FROM products ORDER BY id DESC", null).use { c -> while(c.moveToNext()) out += Product(c.getLong(0),c.getString(1),c.getDouble(2),c.getDouble(3),c.getDouble(4)) }; return out
    }
    fun addTransaction(kind: String, title: String, amount: Double) {
        writableDatabase.insert("transactions", null, ContentValues().apply { put("kind",kind); put("title",title); put("amount",amount) })
    }
    fun total(kind: String): Double { readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind=?", arrayOf(kind)).use { it.moveToFirst(); return it.getDouble(0) } }
    fun transactionRows(): List<String> { val a= mutableListOf<String>(); readableDatabase.rawQuery("SELECT kind,title,amount FROM transactions ORDER BY id DESC LIMIT 100",null).use { c -> while(c.moveToNext()) a += "${c.getString(0)} • ${c.getString(1)} • ${c.getDouble(2)}" }; return a }
}
data class Product(val id:Long,val name:String,val qty:Double,val price:Double,val cost:Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); val db=StoreDb(this); setContent { VentraApp(db) } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun VentraApp(db: StoreDb) {
    var page by remember { mutableStateOf("الرئيسية") }; var refresh by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var qty by remember { mutableStateOf("") }; var price by remember { mutableStateOf("") }; var cost by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }
    val products = remember(refresh) { db.products() }; val sales=remember(refresh){db.total("مبيعات")}; val expenses=remember(refresh){db.total("مصروف")}; val purchases=remember(refresh){db.total("مشتريات")}
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(containerColor=Paper, topBar={ TopAppBar(title={ Column { Text("VENTRA",fontWeight=FontWeight.Black,color=Gold,letterSpacing=2.sp); Text("إدارة أعمالك بسهولة",fontSize=12.sp,color=Color.Gray) } }, colors=TopAppBarDefaults.topAppBarColors(containerColor=Ink,titleContentColor=Color.White)) },
            floatingActionButton={ if(page!="الرئيسية") FloatingActionButton(onClick={dialog=when(page){"المخزون"->"منتج";"المبيعات"->"مبيعات";"المشتريات"->"مشتريات";else->"مصروف"}},containerColor=Gold,contentColor=Ink){Icon(Icons.Default.Add,"إضافة")} },
            bottomBar={ NavigationBar(containerColor=Ink) { listOf("الرئيسية","المخزون","المبيعات","المشتريات","المصروفات","التقارير").forEach { p -> NavigationBarItem(selected=page==p,onClick={page=p},label={Text(p,fontSize=10.sp)},icon={Icon(when(p){"الرئيسية"->Icons.Default.Home;"المخزون"->Icons.Default.Inventory;"المبيعات"->Icons.Default.PointOfSale;"المشتريات"->Icons.Default.ShoppingCart;"المصروفات"->Icons.Default.Receipt;else->Icons.Default.BarChart},p)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Gold,selectedTextColor=Gold,unselectedIconColor=Color.LightGray,unselectedTextColor=Color.LightGray,indicatorColor=Color(0xFF39352A))) } } }
        ) { pad -> Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
            when(page) {
                "الرئيسية" -> { Text("لوحة التحكم",fontSize=23.sp,fontWeight=FontWeight.Bold,color=Ink); Spacer(Modifier.height(14.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ Metric("إجمالي المبيعات",sales); Metric("المشتريات",purchases) }; Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ Metric("المصروفات",expenses); Metric("صافي الحركة",sales-purchases-expenses) }; Spacer(Modifier.height(18.dp)); Text("آخر العمليات",fontWeight=FontWeight.Bold,fontSize=18.sp); TransactionList(db,refresh) }
                "المخزون" -> { Text("المخزون والمنتجات",fontSize=22.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(12.dp)); if(products.isEmpty()) Empty("لا توجد منتجات بعد") else LazyColumn { items(products){ p -> Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){ Column(Modifier.padding(14.dp)){ Text(p.name,fontWeight=FontWeight.Bold); Text("الكمية: ${p.qty}   •   سعر البيع: ${p.price}   •   التكلفة: ${p.cost}",color=Color.Gray,fontSize=13.sp) } } } } }
                "المبيعات","المشتريات","المصروفات" -> { Text(page,fontSize=22.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text("أضف عملية من زر + بالأسفل",color=Color.Gray); TransactionList(db,refresh) }
                else -> { Text("التقارير",fontSize=22.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(12.dp)); Metric("المبيعات",sales); Metric("المشتريات",purchases); Metric("المصروفات",expenses); Metric("صافي الربح التقديري",sales-purchases-expenses); Text("هذه أرقام العمليات المسجلة محلياً على هذا الجهاز.",fontSize=12.sp,color=Color.Gray) }
            }
        } }
    }
    if(dialog.isNotEmpty()) AlertDialog(onDismissRequest={dialog=""},title={Text("إضافة $dialog")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        OutlinedTextField(value=name,onValueChange={name=it},label={Text(if(dialog=="منتج") "اسم المنتج" else "البيان")},singleLine=true)
        if(dialog=="منتج") { NumberField(qty,{qty=it},"الكمية"); NumberField(price,{price=it},"سعر البيع"); NumberField(cost,{cost=it},"التكلفة") } else NumberField(amount,{amount=it},"المبلغ")
    }},confirmButton={TextButton(onClick={
        if(dialog=="منتج" && name.isNotBlank()) db.addProduct(name,qty.toDoubleOrNull()?:0.0,price.toDoubleOrNull()?:0.0,cost.toDoubleOrNull()?:0.0)
        else if(name.isNotBlank() && (amount.toDoubleOrNull()?:0.0)>0) db.addTransaction(when(dialog){"مبيعات"->"مبيعات";"مشتريات"->"مشتريات";else->"مصروف"},name,amount.toDouble())
        name="";qty="";price="";cost="";amount="";dialog="";refresh++
    }){Text("حفظ",color=Gold)}},dismissButton={TextButton(onClick={dialog=""}){Text("إلغاء")}})
}
@Composable fun Metric(label:String,value:Double){ Card(Modifier.width(145.dp).height(100.dp),colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(16.dp)){ Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.Center){ Text(label,color=Color.Gray,fontSize=12.sp); Text("${"%.2f".format(value)}",fontWeight=FontWeight.Bold,fontSize=19.sp,color=Ink) } } }
@Composable fun NumberField(v:String,on:(String)->Unit,label:String){ OutlinedTextField(value=v,onValueChange=on,label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal)) }
@Composable fun Empty(s:String){ Box(Modifier.fillMaxWidth().padding(30.dp),contentAlignment=Alignment.Center){Text(s,color=Color.Gray)} }
@Composable fun TransactionList(db:StoreDb,refresh:Int){ val rows=remember(refresh){db.transactionRows()}; if(rows.isEmpty()) Empty("لا توجد عمليات مسجلة") else LazyColumn { items(rows){ Text(it,Modifier.fillMaxWidth().padding(vertical=9.dp),fontSize=13.sp); Divider(color=Color(0xFFE7E2D7)) } } }
